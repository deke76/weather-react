defmodule Car.Mailer do
  use Swoosh.Mailer, otp_app: :car
end
