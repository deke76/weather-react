docker-compose build $1
