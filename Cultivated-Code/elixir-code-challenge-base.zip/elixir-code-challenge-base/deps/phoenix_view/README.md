# Phoenix.View

Defines the view layer of a Phoenix application.

See the [`Phoenix.View`](https://hexdocs.pm/phoenix_view/Phoenix.View.html) module documentation
for more information.

## Installation

You can install `phoenix_view` by adding it to your list of dependencies in `mix.exs`:

```elixir
def deps do
  [
    {:phoenix_view, "~> 1.0"}
  ]
end
```
