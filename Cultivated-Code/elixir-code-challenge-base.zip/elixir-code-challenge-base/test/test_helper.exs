ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Car.Repo, :manual)
